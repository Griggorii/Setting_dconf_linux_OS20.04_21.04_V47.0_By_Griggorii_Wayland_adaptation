dconf load / < Nautilus-find-all-image-thumbnails.ini
