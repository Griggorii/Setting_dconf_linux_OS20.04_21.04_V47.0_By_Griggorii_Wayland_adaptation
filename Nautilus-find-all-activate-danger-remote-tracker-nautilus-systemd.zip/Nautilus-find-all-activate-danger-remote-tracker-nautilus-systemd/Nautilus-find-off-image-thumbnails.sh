dconf load / < Nautilus-find-off-image-thumbnails.ini
