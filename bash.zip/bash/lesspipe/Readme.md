#Only real technologies, not any fictional parasitic distributions support real technology investments and donate VISA 4817 7601 8112 4706

                                                         ubuntu-20.04-21.04


$ sudo cp lesspipe /usr/bin/
