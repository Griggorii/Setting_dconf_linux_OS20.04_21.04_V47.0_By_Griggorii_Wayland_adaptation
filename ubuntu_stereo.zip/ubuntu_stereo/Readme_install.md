Support https://www.youtube.com/channel/UC6WtVfU5gi2CQ4ionzbz1CQ and donate dollar card visa VISA 4817 7601 8112 4706 thanks

Install sound touch cinnamon / gnome

$ sudo tar -xvpf ubuntu_stereo.tar.xz -C /

$ ./sound.sh


Run dconf-editor

Звуки /org/gnome/desktop/sound/input-feedback-sounds

/com/ubuntu/touch/sound/

/usr/share/sounds/ubuntu/ringtones/Ubuntu.ogg знач по ум
/usr/share/sounds/ubuntu/notifications/Xylo.ogg знач по ум

