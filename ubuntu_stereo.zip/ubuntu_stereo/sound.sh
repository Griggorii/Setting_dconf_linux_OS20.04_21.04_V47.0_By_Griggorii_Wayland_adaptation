dconf load / < sound.ini
