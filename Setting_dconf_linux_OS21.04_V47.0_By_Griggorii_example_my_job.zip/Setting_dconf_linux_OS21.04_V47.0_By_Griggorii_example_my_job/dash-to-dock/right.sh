dconf load / < right.dconf
