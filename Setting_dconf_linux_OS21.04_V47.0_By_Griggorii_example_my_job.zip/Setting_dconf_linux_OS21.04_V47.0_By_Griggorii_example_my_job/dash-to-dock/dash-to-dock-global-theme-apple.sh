dconf load / < dash-to-dock-global-theme-apple.dconf
