dconf load / < icon-size-24.dconf
