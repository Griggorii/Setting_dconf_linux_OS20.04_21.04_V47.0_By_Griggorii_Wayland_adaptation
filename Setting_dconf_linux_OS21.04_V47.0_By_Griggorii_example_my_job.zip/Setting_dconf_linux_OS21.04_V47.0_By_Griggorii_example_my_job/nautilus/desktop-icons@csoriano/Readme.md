#Only real technologies, not any fictional parasitic distributions support real technology investments and donate VISA 4817 7601 8112 4706

                                      Griggorii@gmail.com
                                             
                                       desktop icons extent
                                              
     shell-version 3.38 support beta ubuntu 21.04 gnome 40 support ubuntu lts stable 3.38-40.1.0
                                              
sudo cp -r desktop-icons@csoriano /usr/share/gnome-shell/extensions/

                   terminal folder <tool> command and run click mouse

/tool/dconf-settings-original-restore.sh


                                              Uninstall 
                                              
sudo rm -rf /usr/share/gnome-shell/desktop-icons@csoriano
