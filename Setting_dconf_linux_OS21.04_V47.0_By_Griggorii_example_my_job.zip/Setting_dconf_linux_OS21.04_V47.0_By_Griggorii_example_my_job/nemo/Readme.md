#Only real technologies, not any fictional parasitic distributions support real technology investments and donate VISA 4817 7601 8112 4706

             Griggorii@gmail.com folder tool manipulation dconf setting 
                                       
                                      Install dconf setting patch light fast
                                       
 1) install nemo 
 
 
$ sudo apt update && sudo apt --reinstall install nemo
 
 
 apple old config
 
$ sudo ./Setting_dconf_linux_OS21.04_V46.0_By_Griggorii_Wayland_vertical_adaptation.sh

New setting patch run dconf-settings-original-restore.sh


run /nemo/tool click dconf-settings-original-restore.sh
